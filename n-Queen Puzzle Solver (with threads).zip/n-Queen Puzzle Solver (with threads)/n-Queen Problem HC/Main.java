import java.util.Scanner;
import java.lang.ThreadGroup;
 
public class Main extends Thread {
	
	


	public static void main(String[] args) {
		
	       
		    int n = 0; 
	        try (Scanner s=new Scanner(System.in)) {
	        	while (true){
	        		System.out.println("Enter the number of Queens :");
	        		n = s.nextInt();
	        		if ( n == 2 || n ==3) {
	        			System.out.println("No Solution possible for "+ n +" Queens. Please enter another number");
	        		}
	        		else
	        			break;
	        	}
	        }
	        long timestamp1 = System.currentTimeMillis();
	        
	        System.out.println("Solution to "+ n +" queens using hill climbing search:");
	        
	        HillClimbingSearch hcs = new HillClimbingSearch(n);
	        
			ThreadGroup tGroup = new ThreadGroup("group");
			
			/*for(int i =0; i<n-1; i++){
			Thread t= new Thread(tGroup, hcs);
			t.start();
			}
			*/
			Thread thrd= new Thread(tGroup, hcs);
			Thread thrd1= new Thread(tGroup, hcs);
			Thread thrd2= new Thread(tGroup, hcs);
			Thread thrd3= new Thread(tGroup, hcs);
			Thread thrd4= new Thread(tGroup, hcs);
			Thread thrd5= new Thread(tGroup, hcs);
			Thread thrd6= new Thread(tGroup, hcs);
			Thread thrd7= new Thread(tGroup, hcs);
			Thread thrd8= new Thread(tGroup, hcs);
			Thread thrd9= new Thread(tGroup, hcs);
			Thread thrd10= new Thread(tGroup, hcs);
			Thread thrd11= new Thread(tGroup, hcs);
			Thread thrd12= new Thread(tGroup, hcs);
			Thread thrd13= new Thread(tGroup, hcs);
			Thread thrd14= new Thread(tGroup, hcs);
			Thread thrd15= new Thread(tGroup, hcs);
			Thread thrd16= new Thread(tGroup, hcs);
			Thread thrd17= new Thread(tGroup, hcs);
			Thread thrd18= new Thread(tGroup, hcs);
			Thread thrd19= new Thread(tGroup, hcs);			

			
			thrd.start();
			thrd1.start();
			thrd2.start();
			thrd3.start();
			thrd4.start();
			thrd5.start();
			thrd6.start();
			thrd7.start();
			thrd8.start();
			thrd9.start(); 
			thrd10.start();
			thrd11.start();
			thrd12.start();
			thrd13.start();
			thrd14.start();
			thrd15.start();
			thrd16.start();
			thrd17.start();
			thrd18.start();
			thrd19.start(); 

	       	while(!HillClimbingSearch.completed){

	       	}
			tGroup.interrupt();
			
	        
	        if (hcs.getFinalSolution() != null)
	        	hcs.printState(hcs.getFinalSolution());
	        
	        
	        
	        //Printing the solution
	        long timestamp2 = System.currentTimeMillis();
			
			long timeDiff = timestamp2 - timestamp1;
			System.out.println("Execution Time: "+timeDiff+" ms");
	        
	       
	    }
}